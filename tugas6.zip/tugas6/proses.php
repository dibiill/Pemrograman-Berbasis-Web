<?php
date_default_timezone_set('Asia/Jakarta');

$asal_bandara = [
    "Soekarno Hatta" => 65000,
    "Husein Sastranegara" => 50000,
    "Abdul Rachman Saleh" => 40000,
    "Juanda" => 30000
];

$tujuan_bandara = [
    "Ngurah Rai" => 85000,
    "Hasanuddin" => 70000,
    "Inanwatan" => 90000,
    "Sultan Iskandar Muda" => 60000
];

$maskapai = $_POST['maskapai'] ?? '';
$asal = $_POST['asal'] ?? '';
$tujuan = $_POST['tujuan'] ?? '';
$harga = (int) ($_POST['harga'] ?? 0);
$tanggal = date("Y-m-d");

$pajak = ($asal_bandara[$asal] ?? 0) + ($tujuan_bandara[$tujuan] ?? 0);
$total = $harga + $pajak;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Penerbangan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0">Data Penerbangan</h4>
            </div>
            <div class="card-body">
                <ul class="list-group">
                    <?php
                    $data = [
                        "Tanggal" => $tanggal,
                        "Maskapai" => $maskapai,
                        "Asal" => $asal,
                        "Tujuan" => $tujuan,
                        "Harga Tiket" => "Rp" . number_format($harga, 0, ',', '.'),
                        "Pajak" => "Rp" . number_format($pajak, 0, ',', '.'),
                        "Total Bayar" => "Rp" . number_format($total, 0, ',', '.')
                    ];

                    foreach ($data as $label => $value) {
                        echo "<li class='list-group-item'><strong>$label:</strong> $value</li>";
                    }
                    ?>
                </ul>
                <a href="index.php" class="btn btn-primary mt-3">Kembali</a>
            </div>
        </div>
    </div>
</body>
</html>
