<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="#">
      <img src="image-removebg-preview.png" alt="Logo" width="30" height="30" class="d-inline-block align-text-top me-2">
      Sistem KRS
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="mahasiswa.php">Mahasiswa</a></li>
        <li class="nav-item"><a class="nav-link" href="matakuliah.php">Mata Kuliah</a></li>
        <li class="nav-item"><a class="nav-link" href="datakrs.php">KRS</a></li>
      </ul>
    </div>
  </div>
</nav>
