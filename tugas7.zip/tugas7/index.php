<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="container-fluid">
    <?php include 'navbar.php'; ?>

    <div class="text-center mt-5 p-2">
    <h1 class="display-5 fw-bold">Selamat Datang di Sistem Informasi KRS</h1>
    <p class="lead text-muted">Kelola data mahasiswa, mata kuliah, dan pengambilan KRS dengan mudah.</p>
</div>

<div class="row mt-5 g-4 justify-content-center">
    <div class="col-md-4">
        <div class="card text-center h-100 border-0 shadow-lg hover-scale">
            <div class="card-body">
                <div class="mb-3">
                    <img src="person_fill_icon_159457.webp" width="60">
                </div>
                <h5 class="card-title fw-bold">Data Mahasiswa</h5>
                <p class="card-text text-muted">Lihat dan kelola informasi mahasiswa.</p>
                <a href="mahasiswa.php" class="btn btn-primary">Lihat Data</a>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card text-center h-100 border-0 shadow-lg hover-scale">
            <div class="card-body">
                <div class="mb-3">
                    <img src="open-book.png" width="60">
                </div>
                <h5 class="card-title fw-bold">Mata Kuliah</h5>
                <p class="card-text text-muted">Atur daftar mata kuliah dan jumlah SKS.</p>
                <a href="matakuliah.php" class="btn btn-success">Lihat Data</a>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card text-center h-100 border-0 shadow-lg hover-scale">
            <div class="card-body">
                <div class="mb-3">
                    <img src="https://cdn-icons-png.flaticon.com/512/992/992700.png" width="60">
                </div>
                <h5 class="card-title fw-bold">Data KRS</h5>
                <p class="card-text text-muted">Cek pengambilan mata kuliah oleh mahasiswa.</p>
                <a href="krs.php" class="btn btn-danger">Lihat Data</a>
            </div>
        </div>
    </div>
</div>


</body>
</html>