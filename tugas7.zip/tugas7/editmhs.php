<?php
include 'db.php';

if (!isset($_GET['npm'])) {
    header("Location: mahasiswa.php");
    exit;
}

$npm = $_GET['npm'];
$data = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE npm = '$npm'");
$row = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $jurusan = $_POST['jurusan'];
    $alamat = $_POST['alamat'];
    mysqli_query($conn, "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan', alamat='$alamat' WHERE npm='$npm'");
    header("Location: mahasiswa.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Edit Data Mahasiswa</h2>
    <form method="POST" class="mt-3">
        <div class="mb-3">
            <label>NPM</label>
            <input type="text" class="form-control" value="<?= $row['npm'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= $row['nama'] ?>" required>
        </div>
        <div class="mb-3">
            <label>Jurusan</label>
            <select name="jurusan" class="form-select">
                <option value="Teknik Informatika" <?= $row['jurusan']=='Teknik Informatika' ? 'selected' : '' ?>>Teknik Informatika</option>
                <option value="Sistem Operasi" <?= $row['jurusan']=='Sistem Operasi' ? 'selected' : '' ?>>Sistem Operasi</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Alamat</label>
            <input type="text" name="alamat" class="form-control" value="<?= $row['alamat'] ?>">
        </div>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="mahasiswa.php" class="btn btn-secondary">Batal</a>
    </form>
</body>
</html>
