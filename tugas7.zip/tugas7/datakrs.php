<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="container-fluid">
    <?php include 'navbar.php'; ?>

    <div class="container mt-4 p-4 bg-white shadow rounded-4">
        <a href="index.php" class="btn btn-outline-secondary mb-4">&larr; Kembali ke Dashboard</a>

        <h2>Data Kartu Rencana Studi (KRS)</h2>

        <!-- Form Tambah Data KRS -->
        <form method="POST" class="row g-3 mt-3 mb-4">
            <!-- Dropdown Mahasiswa -->
            <div class="col-md-3">
                <select name="mahasiswa_npm" class="form-select" required>
                    <option selected disabled>Pilih Mahasiswa</option>
                    <?php
                    $mhs = mysqli_query($conn, "SELECT * FROM mahasiswa");
                    while ($m = mysqli_fetch_assoc($mhs)) {
                        echo "<option value='{$m['npm']}'>{$m['npm']} - {$m['nama']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Dropdown Mata Kuliah -->
            <div class="col-md-4">
                <select name="matakuliah_kodemk" class="form-select" required>
                    <option selected disabled>Pilih Mata Kuliah</option>
                    <?php
                    $mk = mysqli_query($conn, "SELECT * FROM matakuliah");
                    while ($m = mysqli_fetch_assoc($mk)) {
                        echo "<option value='{$m['kodemk']}'>{$m['kodemk']} - {$m['nama_mk']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="col-12">
                <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
            </div>
        </form>

        <?php
        if (isset($_POST['simpan'])) {
            $npm = $_POST['mahasiswa_npm'];
            $kodemk = $_POST['matakuliah_kodemk'];

            $query = "INSERT INTO krs (mahasiswa_npm, matakuliah_kodemk) VALUES ('$npm', '$kodemk')";
            if (!mysqli_query($conn, $query)) {
                echo "<div class='alert alert-danger'>Gagal menambahkan data: " . mysqli_error($conn) . "</div>";
            } else {
                echo "<div class='alert alert-success'>Data berhasil ditambahkan!</div>";
            }
        }

        $data = mysqli_query($conn, "SELECT 
            krs.id,
            mahasiswa.nama AS nama_mahasiswa,
            matakuliah.nama AS nama_mk,
            matakuliah.jumlah_sks AS sks
            FROM krs
            JOIN mahasiswa ON krs.mahasiswa_npm = mahasiswa.npm
            JOIN matakuliah ON krs.matakuliah_kodemk = matakuliah.kodemk
        ");
        ?>

        <!-- Tabel Data KRS -->
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Mahasiswa</th>
                    <th>Mata Kuliah</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = mysqli_fetch_assoc($data)): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $row['nama_mahasiswa'] ?></td>
                        <td><?= $row['nama_mk'] ?></td>
                        <td>
                            <span class="highlight"><?= $row['nama_mahasiswa'] ?></span> mengambil mata kuliah 
                            <span class="highlight"><?= $row['nama_mk'] ?></span> (<?= $row['sks'] ?> SKS)
                        </td>
                        <td>
                            <a href="editkrs.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="hapuskrs.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
