<?php 
include 'db.php';

$kodemk = $_GET['kodemk'];
$data = mysqli_query($conn, "SELECT * FROM matakuliah WHERE kodemk='$kodemk'");
$row = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $jumlah_sks = $_POST['jumlah_sks'];
    $q = "UPDATE matakuliah SET nama='$nama', jumlah_sks='$jumlah_sks' WHERE kodemk='$kodemk'";
    mysqli_query($conn, $q);
    header("Location: matakuliah.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Mata Kuliah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Edit Mata Kuliah</h2>
    <form method="POST" class="row g-3">
        <div class="col-md-4">
            <label>Kode Mata Kuliah</label>
            <input type="text" name="kodemk" class="form-control" value="<?= $row['kodemk'] ?>" readonly>
        </div>
        <div class="col-md-4">
            <label>Nama Mata Kuliah</label>
            <input type="text" name="nama" class="form-control" value="<?= $row['nama'] ?>" required>
        </div>
        <div class="col-md-4">
            <label>Jumlah SKS</label>
            <input type="text" name="jumlah_sks" class="form-control" value="<?= $row['jumlah_sks'] ?>" required>
        </div>
        <div class="col-12">
            <button type="submit" name="update" class="btn btn-success">Update</button>
            <a href="matakuliah.php" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</body>
</html>
