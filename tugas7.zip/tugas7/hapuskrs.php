<?php
include 'db.php';

$id_krs = $_GET['id_krs'];
mysqli_query($conn, "DELETE FROM krs WHERE id_krs='$id_krs'");
header("Location: krs.php");
?>
