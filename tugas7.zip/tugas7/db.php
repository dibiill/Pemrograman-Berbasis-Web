<?php
$conn = mysqli_connect("localhost", "root", "", "kuliah");

if (!$conn) {
    die ("Koneksi Gagal: " . mysqli_connect_error());
}
?>