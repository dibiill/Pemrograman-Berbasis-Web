<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Mata Kuliah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="container-fluid bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container mt-4 p-4 bg-white shadow rounded-4">
        <a href="index.php" class="btn btn-outline-secondary mb-4">&larr; Kembali ke Dashboard</a>

        <h2 class="mb-4">Data Mata Kuliah</h2>

        <form action="" method="POST" class="row g-3">
            <div class="col-md-3">
                <input type="text" name="kodemk" class="form-control" placeholder="Kode Mata Kuliah" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="nama" class="form-control" placeholder="Nama Mata Kuliah" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="jumlah_sks" class="form-control" placeholder="Jumlah SKS" required>
            </div>
            <div class="col-12 text-end">
                <button type="submit" name="simpan" class="btn btn-primary">+ Tambah Mata Kuliah</button>
            </div>
        </form>

        <?php
        if (isset($_POST['simpan'])) {
            $kodemk = $_POST['kodemk'];
            $nama = $_POST['nama'];
            $jumlah_sks = $_POST['jumlah_sks'];

            $q = "INSERT INTO matakuliah (kodemk, nama, jumlah_sks) VALUES ('$kodemk', '$nama', '$jumlah_sks')";
            mysqli_query($conn, $q);
        }

        $data = mysqli_query($conn, "SELECT * FROM matakuliah");
        ?>

        <table class="table table-striped table-hover mt-4">
            <thead class="table-dark">
                <tr>
                    <th>KODE MK</th>
                    <th>NAMA MATA KULIAH</th>
                    <th>JUMLAH SKS</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($data)): ?>
                <tr>
                    <td><?= $row['kodemk'] ?></td>
                    <td><?= $row['nama'] ?></td>
                    <td><?= $row['jumlah_sks'] ?></td>
                    <td>
                        <a href="editmk.php?kodemk=<?= $row['kodemk'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="hapusmk.php?kodemk=<?= $row['kodemk'] ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin menghapus <?= $row['nama'] ?>?');">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
