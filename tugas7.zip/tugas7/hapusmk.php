<?php 
include 'db.php';

$kodemk = $_GET['kodemk'];
mysqli_query($conn, "DELETE FROM matakuliah WHERE kodemk='$kodemk'");

header("Location: matakuliah.php");
?>
