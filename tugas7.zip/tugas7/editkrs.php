<?php
include 'db.php';

$id_krs = $_GET['id_krs'];
$result = mysqli_query($conn, "SELECT * FROM krs WHERE id_krs='$id_krs'");
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $npm = $_POST['npm'];
    $kodemk = $_POST['kodemk'];

    $query = "UPDATE krs SET npm='$npm', kodemk='$kodemk' WHERE id_krs='$id_krs'";
    mysqli_query($conn, $query);
    header("Location: krs.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Edit Data KRS</h2>
    <form method="POST" class="mt-4">
        <div class="mb-3">
            <label class="form-label">NPM</label>
            <input type="text" name="npm" class="form-control" value="<?= $data['npm'] ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Kode Mata Kuliah</label>
            <input type="text" name="kodemk" class="form-control" value="<?= $data['kodemk'] ?>" required>
        </div>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="krs.php" class="btn btn-secondary">Batal</a>
    </form>
</body>
</html>
