<?php
include 'db.php';

if (isset($_GET['npm'])) {
    $npm = $_GET['npm'];
    mysqli_query($conn, "DELETE FROM mahasiswa WHERE npm='$npm'");
}
header("Location: mahasiswa.php");
?>
