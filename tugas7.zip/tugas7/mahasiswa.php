<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body class="container-fluid">
    <?php include 'navbar.php'; ?>

    <div class="container mt-4 p-4 bg-white shadow rounded-4">
    <a href="index.php" class="btn btn-outline-secondary mb-4">&larr; Kembali ke Dashboard</a>

    <h2 class="mb-4">Data Mahasiswa</h2>

    <form action="" method="POST" class="row g-3">
        <div class="col-md-3">
            <input type="text" name="npm" class="form-control" placeholder="NPM" required>
        </div>
        <div class="col-md-3">
            <input type="text" name="nama" class="form-control" placeholder="Nama" required>
        </div>
        <div class="col-md-3">
            <select name="jurusan" class="form-select" required>
                <option disabled selected>Pilih Jurusan</option>
                <option value="Teknik Informatika">Teknik Informatika</option>
                <option value="Sistem Operasi">Sistem Operasi</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="text" name="alamat" class="form-control" placeholder="Alamat">
        </div>
        <div class="col-12 text-end">
            <button type="submit" name="simpan" class="btn btn-primary">+ Tambah Mahasiswa</button>
        </div>
    </form>

    <?php
    if (isset($_POST['simpan'])) {
        $q = "INSERT INTO mahasiswa VALUES ('{$_POST['npm']}', '{$_POST['nama']}', '{$_POST['jurusan']}', '{$_POST['alamat']}')";
        mysqli_query($conn, $q);
        header("Location: mahasiswa.php");
        exit;
    }
    $data = mysqli_query($conn, "SELECT * FROM mahasiswa");
    ?>

    <table class="table table-striped table-hover mt-4">
        <thead class="table-dark">
            <tr>
                <th>NPM</th>
                <th>Nama</th>
                <th>Jurusan</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row = mysqli_fetch_assoc($data)): ?>
            <tr>
                <td><?= $row['npm'] ?></td>
                <td><?= $row['nama'] ?></td>
                <td><?= $row['jurusan'] ?></td>
                <td><?= $row['alamat'] ?></td>
                <td>
                    <a href="editmhs.php?npm=<?= $row['npm'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="hapusmhs.php?npm=<?= $row['npm'] ?>" class="btn btn-danger btn-sm"
                    onclick="return confirm('Yakin ingin menghapus <?= $row['nama'] ?>?');">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>


</body>
</html>

